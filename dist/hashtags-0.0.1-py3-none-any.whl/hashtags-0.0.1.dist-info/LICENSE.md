Copyright 2018 Forest Mars

Some rights reserved.

# All software should ship with a license, even if it's only an exercise.

This software is provided to Eigen Technologies as an example exercise as part of the hiring process, and may be used in any reasonable manner stemming from this purpose.

Other uses, including repurposing, redistribution in source or binary forms or reproduction including quotation must be explicitly preauthorized by license holder.

This sofware is provided "AS IS" with no warranty express or implied. Author shall not be held liable on any theory of liability, whether in codeontract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, for its intended purpose or otherwise, including damage to any systems or data, or even psychological damage of seeing code that could (always) stand to be improved! 

Thank you for reading this.
